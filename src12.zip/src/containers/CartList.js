import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
    selectGoods
} from '../store/goodsSlice';

import { selectCart } from '../store/cartSlice';


function CartList() {
    const goods = useSelector(selectGoods);
    const cart = useSelector(selectCart);
    // reindex items
    const goodsObj = goods.reduce((accum, item) => {
        accum[item['articul']] = item;
        return accum;
    }, {});

    console.log(goodsObj);

    return (
        <div>
            <ul>
                {Object.keys(cart).map(elem => <li key={elem + goodsObj[elem]['title']}>{goodsObj[elem]['title']}-{cart[elem]}</li>)}
            </ul>
        </div>
    );
}

export default CartList;